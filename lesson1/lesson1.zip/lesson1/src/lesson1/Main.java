package lesson1;
import java.util.*;

public class Main {

    static class User {
        private Integer id;
        private String name;
        private Integer age;

        public User(){}

        public User(Integer id, String name, Integer age) {
            this.id = id;
            this.name = name;
            this.age = age;
        }

        public Integer getId() {
            return id;
        }

        public void setId(Integer id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public Integer getAge() {
            return age;
        }

        public void setAge(Integer age) {
            this.age = age;
        }

        @Override
        public String toString() {
            return "User{" +
                    "id=" + id +
                    ", name='" + name + '\'' +
                    ", age=" + age +
                    '}';
        }
    }

    private static String generateName(String[] nameArr) {
        StringBuilder builder = new StringBuilder();
        List<String> chars = Arrays.asList(nameArr);
//        Collections.shuffle(chars);
        for (int i = 0; i < 3; i++) {
            builder.append(chars.get(i));
        }
        return builder.toString();
    }

    public static void main(String[] agrs){
        Random r = new Random();
        String[] name = {"f","r","u","i","t"};
        int low = 20;
        int high = 23;
        System.out.println("LIST USER");
        for (int i = 1; i <= 300; i++) {
            int age = r.nextInt(high-low) + low;
            User user = new User();
            user.setId(i);
            user.setName(generateName(name));
            user.setAge(age);
            System.out.println(user.toString());
            }
        }
    }


