package lesson1;

import java.util.Scanner;

public class test {
    public static void main(String[] agrs){
        long sum = 0;
        int n;
        do {
            System.out.println("Nhap so n: ");
            Scanner Scanner = new Scanner(System.in);
            n = Scanner.nextInt();
        }while(n <= 0);
        for(int i = 1; i <= n; i++){
            sum += i;
        }
        System.out.println("Tong bang:" +sum);
    }
}
